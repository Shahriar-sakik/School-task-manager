import sqlite3

def init_db():
    conn = sqlite3.connect('school.db')
    c = conn.cursor()

    # Users table
    c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL
    )
    ''')

    # Tasks table
    c.execute('''
    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        assigned_to TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        submitted_text TEXT,
        subject TEXT
    )
    ''')

    # Add submitted_text column if it doesn't exist (for existing databases)
    try:
        c.execute('ALTER TABLE tasks ADD COLUMN submitted_text TEXT')
    except sqlite3.OperationalError:
        # Column already exists
        pass

    # Add subject column if it doesn't exist (for existing databases)
    try:
        c.execute('ALTER TABLE tasks ADD COLUMN subject TEXT')
    except sqlite3.OperationalError:
        # Column already exists
        pass

    # Grades table
    c.execute('''
    CREATE TABLE IF NOT EXISTS grades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student TEXT NOT NULL,
        task_id INTEGER NOT NULL,
        grade INTEGER,
        subject TEXT,
        teacher TEXT
    )
    ''')

    # Profiles table
    c.execute('''
    CREATE TABLE IF NOT EXISTS profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT,
        full_name TEXT,
        student_number TEXT
    )
    ''')

    # Submissions table
    c.execute('''
    CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL,
        student TEXT NOT NULL,
        text_content TEXT,
        file_name TEXT,
        submitted_at TEXT,
        FOREIGN KEY (task_id) REFERENCES tasks (id)
    )
    ''')

    # Messages table for teacher broadcasts
    c.execute('''
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        teacher TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Clear existing sample data and insert fresh unique tasks
    try:
        # Clear existing data first
        c.execute("DELETE FROM tasks")
        c.execute("DELETE FROM grades")
        
        # Insert 12 unique tasks across different subjects
        tasks_data = [
            ("Algebra Problem Set", "Solve quadratic equations 1-15", "student1", "completed", "Mathematics"),
            ("Biology Lab Report", "Study plant cell structure under microscope", "student1", "completed", "Biology"),
            ("Shakespeare Essay", "Analyze themes in Romeo and Juliet", "student1", "pending", "English Literature"),
            ("Chemical Reactions Lab", "Experiment with acid-base reactions", "student1", "pending", "Chemistry"),
            ("World War II Research", "Research causes and effects of WWII", "student1", "completed", "History"),
            ("Python Programming", "Create a simple calculator program", "student1", "pending", "Computer Science"),
            
            ("Geometry Proofs", "Complete triangle congruence proofs", "student2", "completed", "Mathematics"),
            ("Physics Motion Lab", "Calculate velocity and acceleration", "student2", "pending", "Physics"),
            ("French Vocabulary", "Learn 50 new French words and phrases", "student2", "completed", "French"),
            ("Art Portfolio", "Create 3 sketches using different techniques", "student2", "pending", "Art"),
            ("Economics Essay", "Analyze supply and demand principles", "student2", "completed", "Economics"),
            ("Environmental Science", "Study local ecosystem and biodiversity", "student2", "pending", "Environmental Science")
        ]
        
        for task in tasks_data:
            c.execute("INSERT INTO tasks (title, description, assigned_to, status, subject) VALUES (?, ?, ?, ?, ?)", task)
        
        # Insert corresponding grades for completed tasks
        grades_data = [
            ("student1", 1, 88, "Mathematics", "teacher1"),
            ("student1", 2, 92, "Biology", "teacher1"),
            ("student1", 5, 85, "History", "teacher1"),
            ("student2", 7, 91, "Mathematics", "teacher1"),
            ("student2", 9, 87, "French", "teacher1"),
            ("student2", 11, 89, "Economics", "teacher1")
        ]
        
        for grade in grades_data:
            c.execute("INSERT INTO grades (student, task_id, grade, subject, teacher) VALUES (?, ?, ?, ?, ?)", grade)

        # Add student2 to users table
        c.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)",
                  ("student2", "pass123", "student"))
        
        # Sample profiles
        c.execute("INSERT OR IGNORE INTO profiles (username, email, full_name, student_number) VALUES (?, ?, ?, ?)",
                  ("student1", "student1@school.edu", "John Doe", "ST2024001"))
        c.execute("INSERT OR IGNORE INTO profiles (username, email, full_name, student_number) VALUES (?, ?, ?, ?)",
                  ("student2", "student2@school.edu", "Jane Smith", "ST2024002"))
    except:
        pass

    conn.commit()
    conn.close()

# Initialize database
init_db()
