from database import init_db
init_db()

from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3

app = Flask(__name__)
app.secret_key = 'your-secret-key'

users = {
    "student1": {"password": "pass123", "role": "student"},
    "student2": {"password": "pass123", "role": "student"},
    "teacher1": {"password": "teach123", "role": "teacher"}
}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        selected_role = request.form['role']
        user = users.get(username)

        if user and user["password"] == password:
            # Check if the user's role matches the selected role
            if user['role'] == selected_role:
                session['username'] = username
                session['role'] = user['role']
                return redirect('/dashboard')
            else:
                error_msg = f"This account is not registered as a {selected_role}. Please select the correct role."
                return render_template('login.html', error=error_msg)
        else:
            error_msg = "Invalid username or password. Please check your credentials and try again."
            return render_template('login.html', error=error_msg)
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect('/')

    if session['role'] == 'student':
        return redirect('/student')
    elif session['role'] == 'teacher':
        return redirect('/teacher')

@app.route('/student')
def student_dashboard():
    if session.get('role') == 'student':
        conn = get_db_connection()
        
        # Get tasks statistics
        tasks = conn.execute('SELECT * FROM tasks WHERE assigned_to = ?', 
                           (session['username'],)).fetchall()
        pending_count = len([t for t in tasks if t['status'] == 'pending'])
        completed_count = len([t for t in tasks if t['status'] == 'completed'])
        
        # Get average grade
        grades = conn.execute('SELECT grade FROM grades WHERE student = ?', 
                            (session['username'],)).fetchall()
        average_grade = 0
        if grades:
            average_grade = round(sum(g['grade'] for g in grades) / len(grades))
        
        # Get profile
        profile = conn.execute('SELECT * FROM profiles WHERE username = ?', 
                             (session['username'],)).fetchone()
        
        # Get teacher messages
        messages = conn.execute('SELECT * FROM messages ORDER BY created_at DESC LIMIT 5').fetchall()
        
        conn.close()
        
        return render_template('student_dashboard.html', 
                             username=session['username'],
                             tasks=tasks,
                             pending_count=pending_count,
                             completed_count=completed_count,
                             average_grade=average_grade,
                             profile=profile,
                             messages=messages)
    return redirect('/')

@app.route('/teacher')
def teacher_dashboard():
    if session.get('role') == 'teacher':
        conn = get_db_connection()
        tasks = conn.execute('SELECT * FROM tasks').fetchall()
        
        # Get student progress
        student_progress = conn.execute('''
            SELECT 
                u.username,
                COUNT(t.id) as total_tasks,
                COUNT(CASE WHEN t.status = 'completed' THEN 1 END) as completed_tasks,
                CASE 
                    WHEN COUNT(t.id) > 0 THEN 
                        ROUND((COUNT(CASE WHEN t.status = 'completed' THEN 1 END) * 100.0) / COUNT(t.id))
                    ELSE 0 
                END as progress_percentage
            FROM users u
            LEFT JOIN tasks t ON u.username = t.assigned_to
            WHERE u.role = 'student'
            GROUP BY u.username
            ORDER BY progress_percentage DESC
        ''').fetchall()
        
        # Get recent messages
        recent_messages = conn.execute('''
            SELECT title, created_at 
            FROM messages 
            WHERE teacher = ? 
            ORDER BY created_at DESC 
            LIMIT 3
        ''', (session['username'],)).fetchall()
        
        conn.close()
        return render_template('teacher_dashboard.html', 
                             username=session['username'], 
                             tasks=tasks,
                             student_progress=student_progress,
                             recent_messages=recent_messages)
    return redirect('/')

@app.route('/broadcast_message', methods=['POST'])
def broadcast_message():
    if session.get('role') != 'teacher':
        return redirect('/')
    
    title = request.form['message_title']
    content = request.form['message_content']
    
    conn = get_db_connection()
    conn.execute('INSERT INTO messages (title, content, teacher) VALUES (?, ?, ?)',
                (title, content, session['username']))
    conn.commit()
    conn.close()
    
    flash('Message broadcasted to all students successfully!')
    return redirect('/teacher')

@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    if session.get('role') != 'teacher':
        return redirect('/')
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Add to in-memory users dict
        users[username] = {"password": password, "role": "student"}
        
        # Add to database
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                        (username, password, 'student'))
            conn.commit()
            flash('Student account created successfully!')
        except sqlite3.IntegrityError:
            flash('Username already exists!')
        finally:
            conn.close()
        
        return redirect('/add_student')
    
    return render_template('add_student.html', username=session['username'])

@app.route('/add_task', methods=['GET', 'POST'])
def add_task():
    if session.get('role') != 'teacher':
        return redirect('/')
    
    conn = get_db_connection()
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        assigned_to = request.form['assigned_to']
        subject = request.form['subject']
        
        conn.execute('INSERT INTO tasks (title, description, assigned_to, status, subject) VALUES (?, ?, ?, ?, ?)',
                    (title, description, assigned_to, 'pending', subject))
        conn.commit()
        flash('Task created successfully!')
        conn.close()
        return redirect('/teacher')
    
    # Get all students for the dropdown
    students = conn.execute("SELECT username FROM users WHERE role = 'student'").fetchall()
    conn.close()
    return render_template('add_task.html', username=session['username'], students=students)

@app.route('/view_submissions')
def view_submissions():
    if session.get('role') != 'teacher':
        return redirect('/')
    
    conn = get_db_connection()
    submissions = conn.execute('''
        SELECT t.id, t.title, t.assigned_to, t.submitted_text, t.status, g.grade
        FROM tasks t
        LEFT JOIN grades g ON t.id = g.task_id AND t.assigned_to = g.student
        WHERE t.submitted_text IS NOT NULL AND t.submitted_text != ''
        ORDER BY t.id DESC
    ''').fetchall()
    conn.close()
    return render_template('view_submissions.html', username=session['username'], submissions=submissions)

@app.route('/grade_task/<int:task_id>/<string:student>', methods=['GET', 'POST'])
def grade_task(task_id, student):
    if session.get('role') != 'teacher':
        return redirect('/')
    
    conn = get_db_connection()
    
    if request.method == 'POST':
        grade = int(request.form['grade'])
        
        # Get task subject
        task = conn.execute('SELECT subject FROM tasks WHERE id = ?', (task_id,)).fetchone()
        subject = task['subject'] if task and task['subject'] else request.form.get('subject', 'General')
        
        # Insert or update grade
        conn.execute('''
            INSERT OR REPLACE INTO grades (student, task_id, grade, subject, teacher)
            VALUES (?, ?, ?, ?, ?)
        ''', (student, task_id, grade, subject, session['username']))
        conn.commit()
        flash('Grade assigned successfully!')
        conn.close()
        return redirect('/view_submissions')
    
    # Get task and existing grade
    task = conn.execute('SELECT * FROM tasks WHERE id = ?', (task_id,)).fetchone()
    grade = conn.execute('SELECT * FROM grades WHERE task_id = ? AND student = ?', 
                        (task_id, student)).fetchone()
    conn.close()
    return render_template('grade_task.html', username=session['username'], 
                          task=task, student=student, grade=grade)

@app.route('/edit_task/<int:task_id>', methods=['GET', 'POST'])
def edit_task(task_id):
    if session.get('role') != 'teacher':
        return redirect('/')
    
    conn = get_db_connection()
    
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        assigned_to = request.form['assigned_to']
        subject = request.form['subject']
        
        conn.execute('UPDATE tasks SET title = ?, description = ?, assigned_to = ?, subject = ? WHERE id = ?',
                    (title, description, assigned_to, subject, task_id))
        conn.commit()
        flash('Task updated successfully!')
        conn.close()
        return redirect('/teacher')
    
    task = conn.execute('SELECT * FROM tasks WHERE id = ?', (task_id,)).fetchone()
    students = conn.execute("SELECT username FROM users WHERE role = 'student'").fetchall()
    conn.close()
    return render_template('edit_task.html', username=session['username'], task=task, students=students)

@app.route('/delete_task/<int:task_id>')
def delete_task(task_id):
    if session.get('role') != 'teacher':
        return redirect('/')
    
    conn = get_db_connection()
    conn.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
    conn.execute('DELETE FROM grades WHERE task_id = ?', (task_id,))
    conn.execute('DELETE FROM submissions WHERE task_id = ?', (task_id,))
    conn.commit()
    conn.close()
    flash('Task deleted successfully!')
    return redirect('/teacher')

def get_db_connection():
    conn = sqlite3.connect('school.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/student/tasks')
def student_tasks():
    if session.get('role') != 'student':
        return redirect('/')
    
    conn = get_db_connection()
    tasks = conn.execute('SELECT * FROM tasks WHERE assigned_to = ?', 
                        (session['username'],)).fetchall()
    conn.close()
    return render_template('student_tasks.html', tasks=tasks, username=session['username'])

@app.route('/student/grades')
def student_grades():
    if session.get('role') != 'student':
        return redirect('/')
    
    conn = get_db_connection()
    grades = conn.execute('''
        SELECT g.*, t.title as task_title 
        FROM grades g 
        JOIN tasks t ON g.task_id = t.id 
        WHERE g.student = ?
    ''', (session['username'],)).fetchall()
    conn.close()
    return render_template('student_grades.html', grades=grades, username=session['username'])

@app.route('/student/profile', methods=['GET', 'POST'])
def student_profile():
    if session.get('role') != 'student':
        return redirect('/')
    
    conn = get_db_connection()
    
    if request.method == 'POST':
        email = request.form['email']
        full_name = request.form['full_name']
        student_number = request.form['student_number']
        
        conn.execute('''
            INSERT OR REPLACE INTO profiles (username, email, full_name, student_number)
            VALUES (?, ?, ?, ?)
        ''', (session['username'], email, full_name, student_number))
        conn.commit()
        flash('Profile updated successfully!')
    
    profile = conn.execute('SELECT * FROM profiles WHERE username = ?', 
                          (session['username'],)).fetchone()
    conn.close()
    return render_template('student_profile.html', profile=profile, username=session['username'])

@app.route('/student/tasks/<int:task_id>', methods=['GET', 'POST'])
def task_detail(task_id):
    if session.get('role') != 'student':
        return redirect('/')
    
    conn = get_db_connection()
    
    # Get task details
    task = conn.execute('SELECT * FROM tasks WHERE id = ? AND assigned_to = ?', 
                       (task_id, session['username'])).fetchone()
    
    if not task:
        conn.close()
        return redirect('/student/tasks')
    
    # Get existing submission
    submission = conn.execute('SELECT * FROM submissions WHERE task_id = ? AND student = ?',
                             (task_id, session['username'])).fetchone()
    
    if request.method == 'POST':
        text_content = request.form['text_content']
        mark_complete = 'mark_complete' in request.form
        file_name = None
        
        # Handle file upload
        if 'file_upload' in request.files:
            file = request.files['file_upload']
            if file and file.filename:
                file_name = file.filename
                # In a real app, you'd save the file to disk or cloud storage
        
        # Insert or update submission
        conn.execute('''
            INSERT OR REPLACE INTO submissions (task_id, student, text_content, file_name, submitted_at)
            VALUES (?, ?, ?, ?, datetime('now'))
        ''', (task_id, session['username'], text_content, file_name))
        
        # Update task with submitted text and status
        if mark_complete:
            conn.execute('UPDATE tasks SET status = ?, submitted_text = ? WHERE id = ?', 
                        ('completed', text_content, task_id))
        else:
            conn.execute('UPDATE tasks SET submitted_text = ? WHERE id = ?', 
                        (text_content, task_id))
        
        conn.commit()
        flash('Task submitted successfully!')
        return redirect(f'/student/tasks/{task_id}')
    
    conn.close()
    return render_template('task_detail.html', task=task, submission=submission, username=session['username'])

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
